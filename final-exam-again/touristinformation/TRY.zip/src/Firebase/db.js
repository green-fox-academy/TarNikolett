import firebase from './firebaseConfig.js';

const db = firebase.firestore();

export default db;