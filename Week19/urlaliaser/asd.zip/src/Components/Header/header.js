export default function Header() {
  return (
    <div>
      <h1>URL aliaser</h1>
    </div>
  )
}